<?php

include("menu.php");

    print "<h3>Sonuç:</h3>";
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";
