<?php
/**
 * @package ipara_wooturk
 * Bu eklentinin tüm hakları Tulparstudyo.com'a aittir
 * Eklenti hakları hakkında ahmethamdibayrak@hotmail.com'a eposta gönderebilirsiniz.
 * Tel: 0850 305 3191
 * Version: 1.0.0
 * Plugin URI: https://wootegra.com/ipara_wooturk
 * Plugin Name: Ipara İçin Bin İşlemleri
 * Description: Ipara İçin Bin İşlemleri modülü kullanarak kart tipine ve kart bankasına göre indirimler tanımlayabilirsiniz.
 * Author: Ahmet Hamdi
 * Author URI: https://wooturk.com/
 * License: GPLv2 or later
 * Text Domain: ipara_wooturk
 **/

include_once('functions.php');
